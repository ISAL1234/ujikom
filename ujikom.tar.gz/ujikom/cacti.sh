#!/bin/bash


echo "=================================================================="
echo ""
echo "      INSTALL DAN KONFIGURASI SISTEM MONITORING CACTI             "
echo ""
echo "=================================================================="
echo ""


read -p "Masukan Community SNMP yang digunakan (default public) : " community
read -p "Masukan IP address SNMP (default 0.0.0.0/0) : " ip
read -p "Masukan IP address Server : " ip_server


apt-get install mysql-server phpmyadmin snmpd snmp apache2 php7.0 libapache2-mod-php7.0 rrdtool cacti cacti-spine -y

sed -i 's/agentAddress udp:127.0.0.1:161/#agentAddress udp:127.0.0.1:161/g' /etc/snmp/snmpd.conf

cat >> /etc/snmp/snmpd.conf <<EOL
agentAddress udp:161,udp6:[::1]:161
rocommunity $community $ip
EOL

/etc/init.d/snmpd start
/etc/init.d/snmpd restart

snmpwalk -c $community $ip_server -v2c



