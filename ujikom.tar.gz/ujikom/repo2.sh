#!/bin/bash

clear

mv /etc/apt/sources.list /etc/apt/sources.list.bc

read -p "Masukan URL dari repository (contoh : http://kambing.ui.ac.id/ubuntu/) : " repo

cat >> /etc/apt/sources.list <<EOL
deb $repo xenial main restricted universe multiverse
deb $repo xenial-security main restricted universe multiverse
deb $repo xenial-updates main restricted universe multiverse
deb $repo xenial-proposed main restricted universe multiverse
deb $repo xenial-backports main restricted universe multiverse
EOL

apt-get update

clear




