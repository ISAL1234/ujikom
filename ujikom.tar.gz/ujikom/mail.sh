#!/bin/bash

apt-get install postfix maildrop courier-imap courier-pop -y

clear

maildirmake /etc/skel/Maildir

for((i=1;i<5;i++))
do
adduser user$i --disabled-password --gecos user$i
passwd user$i <<<"user$i"$'\n'"user$i"
done

dpkg-reconfigure postfix

cat >> /etc/postfix/main.cf <<EOL
home_mailbox = Maildir/
EOL

/etc/init.d/postfix restart
/etc/init.d/courier-imap restart
/etc/init.d/courier-pop restart
systemctl enable courier-authdaemon
systemctl start courier-authdaemon

clear

echo "=================================================================="
echo ""
echo "      UJI COBA PENGIRIMAN MAIL                    				"
echo ""
echo "=================================================================="
echo ""

read -p "Masukan Domain Server Mail: " server
read -p "Masukan SMTP Port (default 25): " port
read -p "Masukan Pengirim Email: " from
read -p "Masukan Penerima Email: " to
read -p "Masukan Subject Message: " subject
read -p "Masukan isi Pesan: " pesan

# create message
function mail_input {
echo "ehlo $(hostname -f)"
echo "MAIL FROM: <$from>"
echo "RCPT TO: <$to>"
echo "DATA"
echo "From: <$from>"
echo "To: <$to>"
echo "Subject: $subject"
echo "$pesan."
echo "."
echo "quit"
}



