#!/bin/bash

apt-get install apache2 libapache2-mod-php7.0 php7.0 mysql-server phpmyadmin -y

clear

mkdir -p /home/site/www
chmod 777 /home/site/www

echo "=================================================================="
echo ""
echo "      INSTALL DAN KONFIGURASI WEB Server           				"
echo ""
echo "=================================================================="
echo ""

read -p "Masukan domain server ( example.com ): " domain
read -p "Masukan jumlah subdomain yang dimiliki : " jumlah

mkdir -p /home/site/mail
chmod 755 /home/site/mail

for (( i=1; i <= $jumlah; ++i ))
do
read -p "Masukan subdomain ke-$i ( ex : www ): " sub

mkdir -p /home/site/www/$sub
chmod 755 /home/site/www/$sub

if [[ "$sub" == "cacti" ]]; then
cat >> /etc/apache2/sites-available/ujikom.conf <<EOL
<VirtualHost *:80>
        ServerName $sub.$domain
        ServerAdmin webmaster@$domain
        DocumentRoot /usr/share/cacti/site
        ErrorLog /var/log/apache2/error.log
        CustomLog /var/log/apache2/access.log combined
</VirtualHost>
EOL

cat >> /etc/apache2/apache2.conf <<EOL
<Directory /usr/share/cacti/site>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
</Directory>
EOL

elif [[ "$sub" == "surat" ]]; then
cat >> /etc/apache2/sites-available/ujikom.conf <<EOL
<VirtualHost *:80>
        ServerName $sub.$domain
        ServerAdmin webmaster@$domain
		DocumentRoot /home/site/mail/
        ErrorLog /var/log/apache2/error.log
        CustomLog /var/log/apache2/access.log combined
</VirtualHost>
EOL

cat >> /etc/apache2/apache2.conf <<EOL
<Directory /home/site/mail>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
</Directory>
EOL

elif [[ "$sub" == "www" ]]; then
cat >> /etc/apache2/sites-available/ujikom.conf <<EOL
<VirtualHost *:80>
        ServerName $sub.$domain
        ServerAdmin webmaster@$domain
		DocumentRoot /home/site/www/
        ErrorLog /var/log/apache2/error.log
        CustomLog /var/log/apache2/access.log combined
</VirtualHost>
EOL

cat >> /etc/apache2/apache2.conf <<EOL
<Directory /home/site/www/>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
</Directory>
EOL

else
cat >> /etc/apache2/sites-available/ujikom.conf <<EOL
<VirtualHost *:80>
        ServerName $sub.$domain
        ServerAdmin webmaster@$domain
        DocumentRoot /home/site/www/$sub
        ErrorLog /var/log/apache2/error.log
        CustomLog /var/log/apache2/access.log combined
</VirtualHost>
EOL

cat >> /etc/apache2/apache2.conf <<EOL
<Directory /home/site/www/$sub>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
</Directory>
EOL
fi

done

cat >> /home/site/www/index.php <<EOL
<?php
phpinfo();
?>
EOL

read -p "Masukan nama anda : " nama
read -p "Masukan kelas anda : " kelas
read -p "Masukan alamat anda : " alamat
read -p "Masukan nama database baru : " database
read -p "Masukan user database baru : " user_database
read -p "Masukan password user database baru : " pass_database
echo ""
echo "Masukan Password root Database"
mysql -u root -p <<MYSQL_SCRIPT
CREATE DATABASE $database;
CREATE USER '$user_database'@'localhost' IDENTIFIED BY '$pass_database';
GRANT ALL PRIVILEGES ON $database.* TO '$user_database'@'localhost';
FLUSH PRIVILEGES;
MYSQL_SCRIPT

echo "Test Koneksi created."
echo "database	: $nama"
echo "kelas		: $kelas"
echo "alamat	: $alamat"
echo "database	: $database"
echo "Username	: $user_database"
echo "Password	: $pass_database"
echo "Cek Your Web Browser www.$domain"


mkdir -p /home/site/www/db
cat >> /home/site/www/db/index.php <<EOL
<!DOCTYPE html>
<html>
<head>
<style>
table {border-collapse: collapse;}
table, td, th {border: 1px solid black;}
</style>
</head>
<body>
<center>
<table cellpadding="30" >
  <tr>
    <td align="center">TEST KONEKSI DATABASE<br>Database :
	<br> Koneksi Database :	
echo"Sukses<br>";
	}
else {
	echo"Gagal";
}?> </td>
  </tr>
</table>
</center>
</body>
</html>
EOL

sed -i '1 a <?php $nama_db ='$database';' /home/site/www/db/index.php
sed -i '2 a $user_db ='$user_database';' /home/site/www/db/index.php
sed -i '3 a $pass_db ='$pass_database';' /home/site/www/db/index.php
sed -i '4 a $host_db =''localhost;''' /home/site/www/db/index.php
sed -i '5 a $koneksi = mysqli_connect($host_db, $user_db, $pass_db); ?>' /home/site/www/db/index.php
sed -i '18 a <?php echo $nama_db ?>' /home/site/www/db/index.php
sed -i '20 a <?php if ($koneksi){' /home/site/www/db/index.php

mkdir -p /home/site/www/internal
cat >> /home/site/www/internal/index.php<<EOL
<html>
<head>
<style>
table {
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
}
</style>
</head>
<body>
<center>
<table cellpadding="30" >
  <tr>
    <td align="center">UJI KOMPETENSI TKJ SMK NEGERI 1<br>CIMAHI<br> $nama </td>
  </tr>
</table>
</center>
</body>
</html>
EOL

mkdir -p /home/site/www/blog
cat >> /home/site/www/blog/index.php <<EOL
<html>
<head>
<style>
table {
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
}
</style>
</head>
<body>
<center>
<table cellpadding="30" >
  <tr>
    <td align="center">BIODATA DIRI<br>nama : $nama<br> kelas : $kelas <br> alamat : $alamat<br> sekolah : SMKN 1 Cimahi </td>
  </tr>
</table>
</center>
</body>
</html>
EOL

a2ensite ujikom.conf

a2dissite 000-default.conf

sed -i 's/DirectoryIndex index.html index.cgi index.pl index.php index.xhtml index.htm/DirectoryIndex index.php index.cgi index.pl index.html index.xhtml index.htm/g' /etc/apache2/mods-enabled/dir.conf

/etc/init.d/apache2 restart





