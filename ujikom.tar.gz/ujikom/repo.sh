#!/bin/bash

mv /etc/apt/sources.list /etc/apt/sources.list.bc
# Open file descriptor (fd) 3 for read/write on a text file.

cat >> /etc/apt/sources.list <<EOL
deb http://id.archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse
deb-src http://id.archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse
deb http://id.archive.ubuntu.com/ubuntu/ xenial-security main restricted universe multiverse
deb http://id.archive.ubuntu.com/ubuntu/ xenial-updates main restricted universe multiverse
deb http://id.archive.ubuntu.com/ubuntu/ xenial-proposed main restricted universe multiverse
deb http://id.archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse
deb-src http://id.archive.ubuntu.com/ubuntu/ xenial-security main restricted universe multiverse
deb-src http://id.archive.ubuntu.com/ubuntu/ xenial-updates main restricted universe multiverse
deb-src http://id.archive.ubuntu.com/ubuntu/ xenial-proposed main restricted universe multiverse
deb-src http://id.archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse
deb http://archive.canonical.com/ubuntu xenial partner
deb-src http://archive.canonical.com/ubuntu xenial partner
EOL

apt-get update




