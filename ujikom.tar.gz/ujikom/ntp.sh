#!/bin/bash

apt-get install dbus -y

timedatectl set-timezone Asia/Jakarta
timedatectl set-ntp no
timedatectl

apt-get install ntp ntpdate -y

clear

sed -i 's/pool 0.ubuntu.pool.ntp.org iburst/# pool 0.ubuntu.pool.ntp.org iburst/g' /etc/ntp.conf
sed -i 's/pool 1.ubuntu.pool.ntp.org iburst/# pool 1.ubuntu.pool.ntp.org iburst/g' /etc/ntp.conf
sed -i 's/pool 2.ubuntu.pool.ntp.org iburst/# pool 2.ubuntu.pool.ntp.org iburst/g' /etc/ntp.conf
sed -i 's/pool 3.ubuntu.pool.ntp.org iburst/# pool 3.ubuntu.pool.ntp.org iburst/g' /etc/ntp.conf

read -p "Masukan IP Address server : " ip

read -p "Masukan Tanggal Sekarang (YYYY-MM-DD) : " tanggal

read -p "Masukan jam Sekarang (HH:MM:SS) : " waktu


cat >> /etc/ntp.conf <<EOL
pool 0.id.pool.ntp.org iburst
pool 1.id.pool.ntp.org iburst
pool 2.id.pool.ntp.org iburst
pool 3.id.pool.ntp.org iburst
server $ip iburst
EOL

/etc/init.d/ntp restart

ntpq -p

ntpdate -u $ip
ntpdate -q $ip
ntpdate -q

date




