#!/bin/bash

max=50
clear
for (( i=1; i <= $max; ++i ))
do
echo "-------------------------------------------"
echo "| No | Menu | XIII TKJ A                  |"
echo "-------------------------------------------"
echo "| [1]  Repository                  	  |"
echo "| [2]  DNS Server                  	  |"
echo "| [3]  WEB Server dan Database            |"
echo "| [4]  Mail Server                 	  |"
echo "| [5]  WEBMAIL                     	  |"
echo "| [6]  SSH Server                  	  |"
echo "| [7]  NTP Server                  	  |"
echo "| [8] Cacti Server                	  |"
echo "| [9] Tambah Domain                	  |"
echo "| [10] Kirim Pesan Via Telnet      	  |"
echo "-------------------------------------------"
echo ""
read -p "Pilih paket aplikasi yang akan di install [1]-[9] / tekan [q] untuk keluar : " menu

if [[ "$menu" == "1" ]]; then
clear
echo "------------------------------------"
echo "| Pilih Repository                 |"
echo "------------------------------------"
echo "| [1]  Global Indonesia            |"
echo "| [2]  Custom                      |"
echo "| [3]  TKJ                         |"
echo "------------------------------------"
echo ""
read -p "Pilih paket aplikasi Repository [1]-[3] : " repo_cus
if [[ "$repo_cus" == "1" ]]; then
	echo ""
	read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_x
    if [[ "$proses_x" == "y" ]]; then
	./repo.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_x
	if [[ "$next_x" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi	

	elif [[ "$repo_cus" == "2" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_z
	if [[ "$proses_z" == "y" ]]; then
	./repo2.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_z
	
		if [[ "$next_z" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi

	elif [[ "$repo_cus" == "3" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_za
	if [[ "$proses_za" == "y" ]]; then
	./repotkj.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_za
	
		if [[ "$next_za" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi

fi

	
	elif [[ "$menu" == "2" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_b
	if [[ "$proses_b" == "y" ]]; then
	./dns.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_b
		if [[ "$next_b" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi

elif [[ "$menu" == "3" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_c
	if [[ "$proses_c" == "y" ]]; then
	./web.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_c
		if [[ "$next_c" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi

elif [[ "$menu" == "4" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_d
	if [[ "$proses_d" == "y" ]]; then
	./mail.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_d
		if [[ "$next_d" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi
	
elif [[ "$menu" == "5" ]]; then
clear
echo "------------------------------------"
echo "| Pilih WebMail yang diinginkan    |"
echo "------------------------------------"
echo "| [1]  Rainloop                    |"
echo "| [2]  Squirrelmail                |"
echo "------------------------------------"
echo ""
read -p "Pilih paket aplikasi WebMail [1]-[2] : " menu_webmail
if [[ "$menu_webmail" == "1" ]]; then
	echo ""
	read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_f
    if [[ "$proses_f" == "y" ]]; then
	./webmailrainloop.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_f
	if [[ "$next_f" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi
	
elif [[ "$menu_webmail" == "2" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_g
	if [[ "$proses_g" == "y" ]]; then
	./webmailsquirrelmail.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_g
	
		if [[ "$next_g" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi
fi
		
elif [[ "$menu" == "6" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_i
	if [[ "$proses_i" == "y" ]]; then
	./ssh.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_i
		if [[ "$next_i" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi
	
elif [[ "$menu" == "7" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_j
	if [[ "$proses_j" == "y" ]]; then
	./ntp.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_j
		if [[ "$next_j" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi
	
elif [[ "$menu" == "8" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_k
	if [[ "$proses_k" == "y" ]]; then
	./cacti.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_k
		if [[ "$next_k" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi


elif [[ "$menu" == "9" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_k
	if [[ "$proses_k" == "y" ]]; then
	./tambahdomain.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_k
		if [[ "$next_k" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi

	
elif [[ "$menu" == "10" ]]; then
	echo ""
    read -p "Apakah anda akan melanjutkan proses (y/n) : " proses_k
	if [[ "$proses_k" == "y" ]]; then
	./testmail.sh
	echo ""
	read -p "Kembali ke menu  (y/n) : " next_k
		if [[ "$next_k" == "y" ]]; then
		     clear
		else 
		     exit
			 clear
		fi
	fi
	
	
elif [[ "$menu" == "q" ]]; then
        exit

fi
clear
done 




