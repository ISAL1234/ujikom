#!/bin/bash

apt-get install bind9 dnsutils -y

clear

echo "======================================="

echo "Konfigurasi DNS"

echo "======================================="
echo ""

read -p "Masukan hostname : " hosts
read -p "Masukan IP Address Server : " ip_server
read -p "Masukan Domain Server ( example.com )  : " domain
read -p "Masukan Jumlah subdomain yang akan ditambahkan : " jumlah 




cat >> /etc/bind/named.conf.local <<EOL
zone "$domain" {
	type master;
	file "/etc/bind/db.forward1";
#	allow-transfer { 172.16.16.123; };
};
EOL


cat >> /etc/bind/db.forward1 <<EOL
;
; BIND data file for local loopback interface
;
!!604800
@       IN      SOA     $domain. root.$domain. (
                     2019040100         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@       IN      NS      $domain.
		IN	MX 10	surat.$domain.
        IN      A       $ip_server
ns	IN	A	$ip_server
EOL

cat >> /etc/bind/db.reverse <<EOL
$oktet_4	IN      PTR     $domain.
EOL

sed -i 's/!!604800/$TTL    604800/g' /etc/bind/db.forward1

max=$jumlah
for (( i=1; i <= $max; ++i ))
do
read -p "Masukan Subdomain ke $i (contoh : www) : " sub

cat >> /etc/bind/db.reverse <<EOL
$oktet_4	IN	PTR	$sub.$domain.
EOL

sed -i '15 a '$sub'	IN	A	'$ip_server'' /etc/bind/db.forward1
done

/etc/init.d/bind9 restart

nslookup $domain
nslookup $ip_server

cat >> /etc/hosts <<EOL
$ip_server	$domain $hosts
EOL

