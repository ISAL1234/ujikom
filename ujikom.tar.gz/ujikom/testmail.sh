#!/bin/bash

echo "=================================================================="
echo ""
echo "      UJI COBA PENGIRIMAN MAIL                    				"
echo ""
echo "=================================================================="
echo ""

read -p "Masukan Domain Server Mail: " server
read -p "Masukan SMTP Port (default 25): " port
read -p "Masukan Pengirim Email: " from
read -p "Masukan Penerima Email: " to
read -p "Masukan Subject Message: " subject
read -p "Masukan isi Pesan: " pesan

# create message
function mail_input {
echo "ehlo $(hostname -f)"
echo "MAIL FROM: <$from>"
echo "RCPT TO: <$to>"
echo "DATA"
echo "From: <$from>"
echo "To: <$to>"
echo "Subject: $subject"
echo "$pesan."
echo "."
echo "quit"
}

mail_input | netcat $server $port || err_exit 



