#!/bin/bash

apt-get install squirrelmail -y

clear

cp -r /usr/share/squirrelmail /home/site/

mv /home/site/squirrelmail/* /home/site/mail

chown www-data:www-data /home/site/mail/ -R

/etc/init.d/apache2 restart





