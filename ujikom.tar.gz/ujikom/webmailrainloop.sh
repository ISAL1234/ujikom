#!/bin/bash

apt-get install php7.0-curl curl php7.0-xml php7.0-mbstring php7.0-mbstring php7.0-gettext unzip -y

clear

cd /home/site/

wget http://repository.rainloop.net/v1/rainloop-latest.zip

unzip rainloop-latest.zip -d /home/site/mail

chown www-data:www-data /home/site/mail/ -R

/etc/init.d/apache2 restart





