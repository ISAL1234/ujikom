#!/bin/bash

apt-get install openssh-server -y
read -p "Masukan Port awal SSH (default 22) : " port_awal
read -p "Masukan Port Perubahan SSH : " port_akhir
read -p "Masukan User yang hanya diijinkan akses SSH : " user
sed -i 's/Port '$port_awal'/Port '$port_akhir'/g' /etc/ssh/sshd_config
sed -i 's/PermitRootLogin prohibit-password/PermitRootLogin no/g' /etc/ssh/sshd_config
cat >> /etc/ssh/sshd_config <<EOL
AllowUsers $user
EOL

cat >> /etc/sudoers <<EOL
$user ALL=(ALL:ALL) ALL
EOL

/etc/init.d/ssh restart




