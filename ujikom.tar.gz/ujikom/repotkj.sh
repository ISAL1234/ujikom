#!/bin/bash

clear

mv /etc/apt/sources.list /etc/apt/sources.list.bc

cat >> /etc/apt/sources.list <<EOL
deb http://172.16.16.8/ubuntu/mirror/vn.archive.ubuntu.com/ubuntu xenial main restricted universe multiverse
deb http://172.16.16.8/ubuntu/mirror/vn.archive.ubuntu.com/ubuntu xenial-security main restricted universe multiverse
deb http://172.16.16.8/ubuntu/mirror/vn.archive.ubuntu.com/ubuntu xenial-updates main restricted universe multiverse
deb http://172.16.16.8/ubuntu/mirror/vn.archive.ubuntu.com/ubuntu xenial-proposed main restricted universe multiverse
deb http://172.16.16.8/ubuntu/mirror/vn.archive.ubuntu.com/ubuntu xenial-backports main restricted universe multiverse
EOL

apt-get update

clear




